# NTU CNS Homework 2 - CTF

## Little Knowledge Proof

In this sub problem (b), just execute `code5b.py` directly and TA should get the flag properly.

## So Anonymous, So Hidden

In subproblem (a), just execute `code7a.py` directly but TA should wait for the flag until the connection is over. Maybe 30 seconds.

In subproblem (b), I just provide my unsuccessful code for TA that prove my effort